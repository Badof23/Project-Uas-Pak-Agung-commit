    <footer>
        <p>&copy; 2022 - Faris Aryano Pirsada - 312010371 - TI.20.A.2 - Universitas Pelita Bangsa - Cikarang Selatan</p>
    </footer>
    </div>
</body>
</html>
